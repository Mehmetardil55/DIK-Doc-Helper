//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by thirstyDevs on 16/05/23.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
