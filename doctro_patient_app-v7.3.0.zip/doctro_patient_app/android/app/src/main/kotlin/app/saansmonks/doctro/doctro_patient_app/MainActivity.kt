package app.saansmonks.doctro.doctro_patient_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
