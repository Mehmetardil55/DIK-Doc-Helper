abstract class Model {
  int? id;

  static fromMap() {}

  toMap() {}
}
