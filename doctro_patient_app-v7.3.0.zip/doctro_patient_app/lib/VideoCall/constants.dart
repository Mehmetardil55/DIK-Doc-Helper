class Constants {
  static const double BOTTOM_PADDING_PIP = 16;
  static const double VIDEO_HEIGHT_PIP = 300;
  static const double VIDEO_TITLE_HEIGHT_PIP = 200;
}
