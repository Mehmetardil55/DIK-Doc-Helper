import 'package:flutter/material.dart';

class PopupChoices {
  String title;
  IconData icon;

  PopupChoices({required this.title, required this.icon});
}
