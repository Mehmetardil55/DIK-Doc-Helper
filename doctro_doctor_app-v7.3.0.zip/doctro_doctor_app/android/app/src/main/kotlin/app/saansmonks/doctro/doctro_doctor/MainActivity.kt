package app.saansmonks.doctro.doctro_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
