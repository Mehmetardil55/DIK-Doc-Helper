//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by thirstyDevs on 27/12/23.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
